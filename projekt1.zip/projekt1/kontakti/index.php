<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="http://localhost/projekt1/"><img src="noted1.png" style="height:40px"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>


  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/projekt1/home">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/">Download</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/tutorial">Tutorial</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/projekt1/kontakti">Kontakt <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/faq">FAQ</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-warning my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-sm col-md-8">
<form class="testklasa formklasa" style="padding-top:3%">
<div class="form-group">
    <label for="imeprezime">Vaše Ime i Prezime</label>
    <input type="name" class="form-control" id="imeprezime"  placeholder="Ime i Prezime">
  </div>
  <div class="form-group">
    <label for="useremail">Vaša E-Mail Adresa</label>
    <input type="email" class="form-control" id="useremail" placeholder="Email">
  </div>
  <div class="form-group" >
    <label for="upit">Vaš Upit:</label>
    <textarea class="form-control" id="upit" rows="7"></textarea>
  </div>
  <div class="buttonpadding"><button type="submit" class="btn btn-primary btn-lg ">Pošalji</button></div>
</form>
</div>
<div class="col-sm col-md-4" style="padding-top:5%">
<div style="height:80%;width:100%">
<p style="color:black;font-size:24px;margin-left:1%">Informacije kontakta:</p>
  <p style="color:black;font-size:18px;margin-left:1%">Adresa: Ulica 123</p>
  <p style="color:black;font-size:18px;margin-left:1%">Email Adresa: Netko@email.hr</p>
  <p style="color:black;font-size:18px;margin-left:1%">Broj Mobitela: +385 98 111 1111</p>
</div>
</div>
</div>
</div>
<div style="padding-bottom:3%"></div>

<!-- karta -->
<div class="embed-responsive embed-responsive-21by9 kartaklasa"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2804.5199788176!2d14.421708476134794!3d45.33831487107212!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4764a0e031fe8c9d%3A0x670190c9dd8e38dd!2sPolytechnic%20of%20Rijeka!5e0!3m2!1sen!2shr!4v1743497081242!5m2!1sen!2shr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
  <div style="padding-top:5%"></div>
  <div class="p-2" style="left:0;bottom:0;width:100%;background-color:#404040">
  <p style="color:white;font-size:16px;margin-left:3%">Kontaktirajte Nas:</p>
  <p style="color:white;font-size:12px;margin-left:3%">Ulica 123</p>
  <p style="color:white;font-size:12px;margin-left:3%">Netko@email.hr</p>
  <p style="color:white;font-size:12px;margin-left:3%">+385 98 111 1111</p>
</div>
</body>
<style>

.navbar-light {
    background-color: #FFEBAA !important;
}
</style>
</html>