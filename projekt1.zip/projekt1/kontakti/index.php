<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="projekt1/cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-inverse" style="background-color:#FFEBAA;">
<div class="container-fluid d-flex navsizeklasa">
	<!-- class=img-responsive maknut kako ikona u nav baru ne mijenja velicinu sa ekranom, te u style max-width:7%; zamijenjen sa obicnim width-->
	<div class="notedklasa2"><img class="p-2 navClassImage" src="bookicon.png"></div>
	<div class="navClassFont notedklasa1"><p class="p-2"><em>Noted!</em></p></div>
	<!-- kako bi tekst skalirao sa buttonom stavimo mu font size u vm(viewport width) umjesto pixele-->
	<!--<button type="button" class="rounded-pill ml-auto p-2" style="background-color: #FFFDE7; width:8%; min-width:80px; height: 50px; font-size: vw;">Home</button>-->
  <div class="btn-group">
  <button class="btn btn-secondary btn-lg dropdown-toggle " type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:orange"><img src="ham.png" style="height:20px;padding-bottom:5px"></img></button>
  <div class="dropdown-menu">
    <a href="http://localhost/projekt1/"><button class="dropdown-item" type="button">Downloads</button></a>
    <a href="http://localhost/projekt1/kontakti/"><button class="dropdown-item" type="button" onclick="document.location='kontakti'">Kontakt</button></a>
    <a href="http://localhost/projekt1/tutorial/"><button class="dropdown-item" type="button" onclick="document.location='kontakti'">Tutorial</button></a>
    <button class="dropdown-item" type="button">4</button>
  </div>
</div>
</div>
</div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-8">
<form class="testklasa formklasa" style="padding-top:3%">
<div class="form-group">
    <label for="imeprezime">Vaše Ime i Prezime</label>
    <input type="name" class="form-control" id="imeprezime"  placeholder="Ime i Prezime">
  </div>
  <div class="form-group">
    <label for="useremail">Vaša E-Mail Adresa</label>
    <input type="email" class="form-control" id="useremail" placeholder="Email">
  </div>
  <div class="form-group" >
    <label for="upit">Vaš Upit:</label>
    <textarea class="form-control" id="upit" rows="7"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Pošalji</button>
</form>
</div>
<div class="col-4" style="padding-top:5%">
<div style="height:80%;width:100%">
<p style="color:black;font-size:24px;margin-left:3%">Informacije kontakta:</p>
  <p style="color:black;font-size:18px;margin-left:3%">Adresa: Ulica 123</p>
  <p style="color:black;font-size:18px;margin-left:3%">Email Adresa: Netko@email.hr</p>
  <p style="color:black;font-size:18px;margin-left:3%">Broj Mobitela: +385 98 111 1111</p>
</div>
</div>
</div>
</div>
<div style="padding-bottom:3%"></div>

<!-- karta -->
<div class="embed-responsive embed-responsive-21by9 kartaklasa"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2804.5199788176!2d14.421708476134794!3d45.33831487107212!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4764a0e031fe8c9d%3A0x670190c9dd8e38dd!2sPolytechnic%20of%20Rijeka!5e0!3m2!1sen!2shr!4v1743497081242!5m2!1sen!2shr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
  <div style="padding-top:5%"></div>
  <div style="left:0;bottom:0;width:100%;background-color:#404040">
  <p style="color:white;font-size:16px;margin-left:3%">Kontaktirajte Nas:</p>
  <p style="color:white;font-size:12px;margin-left:3%">Ulica 123</p>
  <p style="color:white;font-size:12px;margin-left:3%">Netko@email.hr</p>
  <p style="color:white;font-size:12px;margin-left:3%">+385 98 111 1111</p>
</div>
</body>
<style>
  .navClassFont{
  font-size:72px;
}
@media (max-width:576px){
  .navClassFont{
    font-size:40px;
  }
}

.navClassImage{
    width:95px;
  }
@media (max-width:576px){
  .navClassImage{
    width:65px;
  }
}
.testklasa {
  padding-left:20px
}

.formklasa{
padding-left:10%;padding-right:20%
}

@media(max-width:576px){
  .formklasa{
padding-left:10%;padding-right:10%
}
}

.kartaklasa{
  width:75%; left:10%;right:10%;
}

@media(max-width:576px){
  .kartaklasa{
  width:90%; left:7%;right:5%
}
}


.notedklasa1{
  padding-right:72%;
}

@media (max-width:576px){
  .notedklasa1{
  padding-right:22%;
}
}

.notedklasa2{
  padding-left:0%;
}

@media (max-width:576px){
  .notedklasa2{
  padding-left:15%;
}
}

.navsizeklasa{}

@media (max-width:576px){
  .navsizeklasa{
    height:75px;
  }}

</style>
</html>