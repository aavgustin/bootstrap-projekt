<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="http://localhost/projekt1/home"><img src="../noted1.png" style="height:40px"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>


  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/home">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/">Download</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/tutorial">Tutorial</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/projekt1/kontakti">Kontakt</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/projekt1/tablica">Tablica</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/projekt1/faq">FAQ <span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>

<div style="background-color:#404040;width:100%; height: 400px" id="carouselControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <div class="d-flex justify-content-center" style="padding-top:25px">
      <img class="d-block w-100 img-fluid carouselStyle1" style="height:350px; align:center;" src="../slide1.png">
    </div>
    </div>
    <div class="carousel-item">
      <div class="d-flex justify-content-center" style="padding-top:25px">
      <img class="d-block w-100 img-fluid carouselStyle1" style="height:350px; align:center;" src="../slide2.png">
      </div>
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-target="#carouselontrols" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselControls" data-slide="next">
    <span class="carousel-control-next-icon"></span>
    <span class="sr-only">Next</span>
  </button>
</div>


<div class="naslovklasa" style="padding-top:5%"><p>Često postavljena pitanja</p>

<div>
    <p class="tutklasa">Što je <em>Noted!?</em></p>
    <p class="tutklasamini"> <em>Noted!</em> je aplikacija za bilješke koja omogućuje spremanje ideja, popisa zadataka, dokumenata, te organizaciju sadržaja na jednom mjestu</p>
</div>
<div>
    <p class="tutklasa">Je li moguće sinkronizirati bilješke na više uređaja?</p>
    <p class="tutklasamini">Da! Noted! podržava sinkronizaciju putem oblaka, tako da je pristupiv preko različitih uređaja </p>
</div>
<div>
    <p class="tutklasa">Postoji li način za pretraživati bilješke?</p>
    <p class="tutklasamini"> Da, preko funckija polja za prezraživanje moguće je pronaći bilješku preko njezinog imena</p>

</div>
<div>
    <p class="tutklasa">Mogu li organizirati bilješke?</p>
    <p class="tutklasamini">Možeš! Unutar Noted! bilješke se mogu organizirati i spremati u mape zvane "notebooks"</p>

</div>
<div>
    <p class="tutklasa">Da li je Noted! besplatan za korištenje</p>
    <p class="tutklasamini">Da, rrenutno postoji jedino besplatna verzija aplikacije Noted! </p>
</div>
</body>
<style>

.navbar-light {
    background-color: #FFEBAA !important;
}
</style>
</html>