<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  


</head>
<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-inverse" style="background-color:#FFEBAA">
<div class="container-fluid">
	<!-- class=img-responsive maknut kako ikona u nav baru ne mijenja velicinu sa ekranom, te u style max-width:7%; zamijenjen sa obicnim width-->
	<img  src="bookicon.png" style= "width:80px;">
	<h1 style="font-size:64px"><em>Noted!</em></h1>
	<!-- kako bi tekst skalirao sa buttonom stavimo mu font size u vm(viewport width) umjesto pixele-->
	<button type="button" class="rounded-pill " style="background-color: #FFFDE7; width:8%; min-width:80px; height: 50px; font-size: vw;">Home</button>
</div>
</nav>
<!-- stupci koji se podešavaju ekranu
<div class="row">
  <div class="col-sm-4">.col-sm-4</div>
  <div class="col-sm-8">.col-sm-8</div>
</div>-->

<!-- table responsive je bootstrap klasa koja ce skalirati down tablicu prema uređaju, width: 1300px sam makno iz style jer onda ne skalira prema uređaju-->
 <!-- flex-column, d-flex, flex-sm-row mozda za buttone da dodu ispod-->
  <!--izgleda da d-flex i row/col sistem nisu kompatabilni-->
   <!--class="col-2 d-flex flex-sm-row flex-column justify-content-between"-->
   <!--d-flex flex-sm-row flex-column-->
<div class="container" style="padding-top:80px;">
    <div class="d-flex justify-content-between">
        <div>
        <img class="img-fluid" style= "width:120px" src="pc.png">
        </div>
        <div>
        <button class="rounded-pill"  style="background-color: #FFEBAA; width:160px; min-width:80px; height: 70px;"><img class="img-responsive" style= "width:40%;" src="download.png">
        </div>
    </div>
    <div class="d-flex justify-content-between">
        <div>
        <img class="img-fluid" style= "width:120px" src="android.png">
        </div>
        <div>
        <button class="rounded-pill"  style="background-color: #FFEBAA; width:160px; min-width:80px; height: 70px;"><img class="img-responsive" style= "width:40%;" src="download.png">
        </div>
    </div>
    <div class="d-flex justify-content-between">
        <div>
        <img class="img-fluid" style= "width:120px" src="apple.png">
        </div>
        <div>
        <button class="rounded-pill"  style="background-color: #FFEBAA; width:160px; min-width:80px; height: 70px;"><img class="img-responsive" style= "width:40%;" src="download.png">
        </div>
    </div>
</div>

<div style="position:fixed;left:0;bottom:0;width:100%;background-color:#404040">
  <p style="color:white;font-size:20px;margin-left:3%">Contacts: aavgustin@veleri.hr</p>
</div>

</body>
</html>