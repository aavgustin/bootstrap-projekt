<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-inverse" style="background-color:#FFEBAA">
<div class="container-fluid d-flex">
	<!-- class=img-responsive maknut kako ikona u nav baru ne mijenja velicinu sa ekranom, te u style max-width:7%; zamijenjen sa obicnim width-->
	<img class="p-2 navClassImage" src="bookicon.png">
	<div class="navClassFont"><p class="p-2"><em>Noted!</em></p></div>
	<!-- kako bi tekst skalirao sa buttonom stavimo mu font size u vm(viewport width) umjesto pixele-->
	<!--<button type="button" class="rounded-pill ml-auto p-2" style="background-color: #FFFDE7; width:8%; min-width:80px; height: 50px; font-size: vw;">Home</button>-->
  <div class="btn-group">
  <button class="btn btn-secondary btn-lg dropdown-toggle " type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:orange"><img src="ham.png" style="height:20px;padding-bottom:5px"></img></button>
  <div class="dropdown-menu">
    <a href="http://localhost/projekt1/"><button class="dropdown-item" type="button">Downloads</button></a>
    <a href="http://localhost/projekt1/kontakti/"><button class="dropdown-item" type="button" onclick="document.location='kontakti'">Kontakti</button></a>
    <a href="http://localhost/projekt1/tutorial/"><button class="dropdown-item" type="button" onclick="document.location='kontakti'">Tutorial</button></a>
    <button class="dropdown-item" type="button">4</button>
  </div>
</div>
</div>
</div>
</nav>

<div style="padding-left:50px;font-size:36px"><p>What is <em>Noted!</em>?</p></div>
<div style="padding-left:50px; padding-right:100px;font-size:24px"><p>Noted! is a desktop and mobile app that allows you to keep your notes up to date wherever and whenever!<br> All your notes in one place connected through the cloud. Write, Save and Sync! Accessible on Android, iOS and Windows PC
</p></div>
</body>
<style>
  .navClassFont{
  font-size:72px;
}
@media (max-width:576px){
  .navClassFont{
    font-size:40px;
  }
}

.navClassImage{
    width:95px;
  }
@media (max-width:576px){
  .navClassImage{
    width:65px;
  }
}
</style>
</html>