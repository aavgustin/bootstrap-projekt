<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-inverse" style="background-color:#FFEBAA;">
<div class="container-fluid d-flex navsizeklasa">
	<!-- class=img-responsive maknut kako ikona u nav baru ne mijenja velicinu sa ekranom, te u style max-width:7%; zamijenjen sa obicnim width-->
	<div class="notedklasa2"><img class="p-2 navClassImage" src="bookicon.png"></div>
	<div class="navClassFont notedklasa1"><p class="p-2"><em>Noted!</em></p></div>
	<!-- kako bi tekst skalirao sa buttonom stavimo mu font size u vm(viewport width) umjesto pixele-->
	<!--<button type="button" class="rounded-pill ml-auto p-2" style="background-color: #FFFDE7; width:8%; min-width:80px; height: 50px; font-size: vw;">Home</button>-->
  <div class="btn-group">
  <button class="btn btn-secondary btn-lg dropdown-toggle " type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color:orange"><img src="ham.png" style="height:20px;padding-bottom:5px"></img></button>
  <div class="dropdown-menu">
    <a href="http://localhost/projekt1/"><button class="dropdown-item" type="button">Downloads</button></a>
    <a href="http://localhost/projekt1/kontakti/"><button class="dropdown-item" type="button" onclick="document.location='kontakti'">Kontakt</button></a>
    <a href="http://localhost/projekt1/tutorial/"><button class="dropdown-item" type="button" onclick="document.location='kontakti'">Tutorial</button></a>
    <button class="dropdown-item" type="button">4</button>
  </div>
</div>
</div>
</div>
</nav>
<div style="background-color:#404040;width:100%; height: 400px" id="carouselControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <div class="d-flex justify-content-center" style="padding-top:25px">
      <img class="d-block w-100 img-fluid carouselStyle1" style="height:350px; align:center;" src="slide1.png">
    </div>
    </div>
    <div class="carousel-item">
      <div class="d-flex justify-content-center" style="padding-top:25px">
      <img class="d-block w-100 img-fluid carouselStyle1" style="height:350px; align:center;" src="slide2.jpg">
      </div>
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-target="#carouselontrols" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselControls" data-slide="next">
    <span class="carousel-control-next-icon"></span>
    <span class="sr-only">Next</span>
  </button>
</div>


<div style="padding-left:50px;font-size:36px"><p>What is <em>Noted!</em>?</p></div>
<div style="padding-left:50px; padding-right:100px;font-size:24px"><p>Noted! is a desktop and mobile app that allows you to keep your notes up to date wherever and whenever!<br> All your notes in one place connected through the cloud. Write, Save and Sync! Accessible on Android, iOS and Windows PC
</p></div>

</body>
<style>
  .navClassFont{
  font-size:72px;
}
@media (max-width:576px){
  .navClassFont{
    font-size:40px;
  }
}

.navClassImage{
    width:95px;
  }
@media (max-width:576px){
  .navClassImage{
    width:65px;
  }
}

.notedklasa1{
  padding-right:72%;
}

@media (max-width:576px){
  .notedklasa1{
  padding-right:22%;
}
}

.notedklasa2{
  padding-left:0%;
}

@media (max-width:576px){
  .notedklasa2{
  padding-left:15%;
}
}

.navsizeklasa{}

@media (max-width:576px){
  .navsizeklasa{
    height:75px;
  }
}
</style>
</html>