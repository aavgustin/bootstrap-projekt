<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-inverse" style="background-color:#FFEBAA">
<div class="container-fluid d-flex">
	<!-- class=img-responsive maknut kako ikona u nav baru ne mijenja velicinu sa ekranom, te u style max-width:7%; zamijenjen sa obicnim width-->
	<img class="p-2" src="bookicon.png" style= "width:95px;">
	<h1 class="p-2" style="font-size:72px"><em>Noted!</em></h1>
	<!-- kako bi tekst skalirao sa buttonom stavimo mu font size u vm(viewport width) umjesto pixele-->
	<button type="button" class="rounded-pill ml-auto p-2" style="background-color: #FFFDE7; width:8%; min-width:80px; height: 50px; font-size: vw;">Home</button>
</div>
</nav>
<!-- stupci koji se podešavaju ekranu
<div class="row">
  <div class="col-sm-4">.col-sm-4</div>
  <div class="col-sm-8">.col-sm-8</div>
</div>-->

<!--slideshow slika preko carousel-->
<div style="background-color:#404040;width:100%; height: 400px" id="carouselControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <div class="d-flex justify-content-center" style="padding-top:25px">
      <img class="d-block w-100 img-fluid carouselStyle1" style="min-width:40%; height:350px; align:center;" src="slide1.png">
    </div>
    </div>
    <div class="carousel-item">
      <div class="d-flex justify-content-center" style="padding-top:25px">
      <img class="d-block w-100 img-fluid carouselStyle1" style="height:350px; align:center;" src="slide2.jpg">
      </div>
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-target="#carouselontrols" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselControls" data-slide="next">
    <span class="carousel-control-next-icon"></span>
    <span class="sr-only">Next</span>
  </button>
</div>


<div style="padding-left:50px;font-size:36px"><p>What is <em>Noted!</em>?</p></div>
<div style="padding-left:50px; padding-right:100px;font-size:24px"><p>Noted! is a desktop and mobile app that allows you to keep your notes up to date wherever and whenever!<br> All your notes in one place connected through the cloud. Write, Save and Sync! Accessible on Android, iOS and Windows PC
</p></div>


<!-- table responsive je bootstrap klasa koja ce skalirati down tablicu prema uređaju, width: 1300px sam makno iz style jer onda ne skalira prema uređaju-->
 <!-- flex-column, d-flex, flex-sm-row mozda za buttone da dodu ispod-->
  <!--izgleda da d-flex i row/col sistem nisu kompatabilni-->
   <!--class="col-2 d-flex flex-sm-row flex-column justify-content-between"-->
   <!--d-flex flex-sm-row flex-column-->
<div class="container" style="padding-top:30px; padding-bottom:100px">
<p style="color:black;font-size:40px;margin-left:3%;text-align:center">Platforms</p>
<div class="d-flex justify-content-between downloadClass">
        <div>
        <img class="img-fluid" style= "width:120px" src="pc.png">
        <span style="font-size:20px">Windows PC</span>
        </div>
        <div style="padding-top:28px">
        <button class="rounded-pill"  style="background-color: #FFEBAA; width:160px; min-width:80px; height: 70px;"><img class="img-responsive" style= "width:40%;" src="download.png">
        </div>
    </div>
    <div class="d-flex justify-content-between downloadClass">
        <div>
        <img class="img-fluid" style= "width:120px" src="android.png">
        <span style="font-size:20px">Android</span>
        </div>
        <div style="padding-top:28px">
        <button class="rounded-pill"  style="background-color: #FFEBAA; width:160px; min-width:80px; height: 70px;"><img class="img-responsive" style= "width:40%;" src="download.png">
        </div>
    </div>
    <div class="d-flex justify-content-between downloadClass">
        <div>
        <img class="img-fluid" style= "width:120px" src="apple.png">
        <span style="font-size:20px">iOS</span>
        </div>
        <div style="padding-top:28px">
        <button class="rounded-pill"  style="background-color: #FFEBAA; width:160px; min-width:80px; height: 70px;"><img class="img-responsive" style= "width:40%;" src="download.png">
        </div>
    </div>
</div>
</div>

<div style="left:0;bottom:0;width:100%;background-color:#404040">
  <p style="color:white;font-size:16px;margin-left:3%">Contact us:</p>
  <p style="color:white;font-size:12px;margin-left:3%">Ulica 123</p>
  <p style="color:white;font-size:12px;margin-left:3%">Netko@email.hr</p>
  <p style="color:white;font-size:12px;margin-left:3%">+385 98 111 1111</p>
</div>
</body>

<!-- carouselStyle1 custom klasa napravljen za carousel kako bi samo na malim uredajima (mobitelu) bio max-width 100%-->
<!-- donwloadClass custom klasa za prebacivanje flex directiona na malim ekranima u column-->
 <!-- update: klase premijestene iz <style> u zaseban fike -->
</html>