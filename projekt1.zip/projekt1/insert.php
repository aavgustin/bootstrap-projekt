<?php
$conn = mysqli_connect("localhost", "root", "", "kontaktbaza");

if ($conn === false) {
    die("nije povezano sa bazom " . mysqli_connect_error());
}

$ime = $_POST['ime'];
$prezime = $_POST['prezime'];
$email = $_POST['email'];
$brojmob = $_POST['brojmob'];
$adresa = $_POST['adresa'];
$firma = $_POST['firma'];
$upit = $_POST['upit'];

$sql = "INSERT INTO formabaza (ime, prezime, email, brojmob, adresa, firma, upit) VALUES ('$ime', '$prezime', '$email', '$brojmob', '$adresa', '$firma', '$upit')";

if (mysqli_query($conn, $sql)) { echo "Forma poslana";    
} else {echo "Greška: " . mysqli_error($conn); 
}

mysqli_close($conn);
?>