<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>


<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="http://localhost/projekt1/"><img src="../noted1.png" style="height:40px"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>


  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/">Download</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/tutorial">Tutorial</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/projekt1/kontakti">Kontakt</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/projekt1/tablica">Tablica <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/projekt1/faq">FAQ</a>
      </li>
    </ul>
  </div>
</nav>

<div class="naslov1"><p>Cjenik Aplikacije</p>
</div>
<!--table-responsive-->
<div class="tableklasa test">
    <table class="table table-striped table-hover">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Verzija Aplikacije</th>
            <th scope="col">Mjesečno</th>
            <th scope="col">Dvo-Mjesečno plaćanje</th>
            <th scope="col">Kvartalno plaćanje.</th>
            <th scope="col">Polu-Anualno plaćanje</th>
            <th scope="col">Anualno plaćanje</th>
            <th scope="col">Jednokratno plaćanje</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="col"> Standardna Verzija</th>
            <td scope="col"> FREE</td>
            <td scope="col"> FREE</td>
            <td scope="col"> FREE</td>
            <td scope="col"> FREE</td>
            <td scope="col"> FREE</td>
            <td scope="col"> FREE</td>
        </tr>
        <tr>
            <th scope="col"> Premium Verzija</th>
            <td scope="col"> 4.99$</td>
            <td scope="col"> 8.99$</td>
            <td scope="col"> 14.99$</td>
            <td scope="col"> 19,99$</td>
            <td scope="col"> 29.99$</td>
            <td scope="col"> 49.99$</td>
        </tr>
        <tr>
            <th scope="col"> Pro Verzija</th>
            <td scope="col"> 6.99$</td>
            <td scope="col"> 10.99$</td>
            <td scope="col"> 16.99$</td>
            <td scope="col"> 21,99$</td>
            <td scope="col"> 32.99$</td>
            <td scope="col"> 54.99$</td>
        </tr>
        <tr>
            <th scope="col"> Mega Verzija</th>
            <td scope="col"> 9.99$</td>
            <td scope="col"> 14.99$</td>
            <td scope="col"> 19.99$</td>
            <td scope="col"> 24,99$</td>
            <td scope="col"> 39.99$</td>
            <td scope="col"> 69.99$</td>
        </tr>
        <tr>
            <th scope="col"> Deluxe Verzija</th>
            <td scope="col"> 19.99$</td>
            <td scope="col"> 24.99$</td>
            <td scope="col"> 29.99$</td>
            <td scope="col"> 34,99$</td>
            <td scope="col"> 49.99$</td>
            <td scope="col"> 89.99$</td>
        </tr>

    </tbody>
    </table>
</div>
<div style="padding-top:15%;">
<div class="p-2" style="left:0;bottom:0;width:100%;background-color:#404040">
  <p style="color:white;font-size:16px;margin-left:3%">Kontaktirajte Nas:</p>
  <p style="color:white;font-size:12px;margin-left:3%">Ulica 123</p>
  <p style="color:white;font-size:12px;margin-left:3%">Netko@email.hr</p>
  <p style="color:white;font-size:12px;margin-left:3%">+385 98 111 1111</p>
</div>
</div>
</body>
<!--
@media(max-width:576px) {
  table.table tr {
    display: table;
    width:100%;
    margin: 3%;
  }
  table.table td,
  table.table th {
    display: table-row;
    text-align:center;
  }
}
-->
<style>

.navbar-light {
    background-color: #FFEBAA !important;
}
.tableklasa{
    padding-top:6%;padding-left:8%;padding-right:8%;
}
.naslov1{
    padding-top:3%;padding-left:40%;font-size:36px
}
@media(max-width:576px){
    .naslov1{
    padding-top:3%;padding-left:28%;font-size:24px
}
}

@media (max-width: 768px) {
  table, thead, tbody, th, td, tr { 
    display: block; 
  }
}
@media (max-width: 768px) {
  thead tr { 
    position: absolute;
    top: -9999px;
    left: -9999px;
  }
}

@media (max-width: 768px) {
  td { 
    display: grid;
    grid-column: 1fr;
    grid-template-columns: 1fr 1fr;
    line-height: 1.5;
    border-bottom: 1px solid #999; 
  }
  
  td:before { 
    font-weight: bold;
    content: attr(data-title);
  }
}
@media (max-width: 480px) {
  td { 
    grid-template-columns: 1fr;
  }
}

</style>

</html>