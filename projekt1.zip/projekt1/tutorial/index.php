<!DOCTYPE html>
<html lang="en">
<head style="background-color:#FFEBAA;">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--meta koja omogucuje mobitelima zoom in i out, tj prilagođava se njihovim ekranima -->
	<title>Document</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../cssStilovi.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body style="background-color:#FFFEF5;">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="http://localhost/projekt1/"><img src="noted1.png" style="height:40px"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/projekt1/home">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/">Download</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/projekt1/tutorial">Tutorial <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/kontakti">Kontakt</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/tablica">Tablica</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="http://localhost/projekt1/faq">FAQ</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-warning my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<div><p class="mx-auto text-center naslov">Upute o Korištenju</p></div>

<div>
  <div>
    <div>
    <p class="tutklasa">1.Prijava računom aplikacije</p>
    <p class="tutklasamini">Ukoliko nemate račun, postoji tipka koja Vas redirektira na stranicu registracije</p>
    </div>
    <div class="row conclass2">
      <div class="col-8 col-md-4">
      <img src="tut1.png" class="tutimage img-fluid">
      </div>
      <div class="col-8 col-md-4">
      <img src="tut1_2.png" class="tutimage img-fluid">
      </div>
    </div>
  </div>
  <div style="background-color:#FFEBAA">
    <p class="tutklasa">2.Navigacija aplikacijom</p>
    <p class="tutklasamini"> Aplikacija je podjeljena u 3 rubrike: Notes, Notebooks i Račun</p>
    <p class="tutklasamini"> Notes je stranica koja sadrži sve Vaše biljepke</p>
    <p class="tutklasamini"> Notebooks je stranica koja sadrži knjige u koje su bilješke organizirane</p>
    <p class="tutklasamini"> Račun sadrži Vaše podatke, kao i postavke računa i aplikacije</p>
    <div class="row conclass ">
      <div class="col-md-4 col-8">
      <img src="tut2.png" class="tutimage img-fluid">
      </div>
      <div class="col-md-4 col-8">
      <img src="tu2_1.png" class="tutimage img-fluid">
      </div>
      <div class="col-md-4 col-8">
      <img src="tut2_2.png" class="tutimage img-fluid">
      </div>
    </div>
</div>
  <div>
    <p class="tutklasa">3.Dodavanje novih bilješci</p>
    <p class="tutklasamini"> Klikom na žutu plus ikonu, otvara se sučelje za pisanje</p>
    <p class="tutklasamini"> Bilješci je potrebno odabrati naziv, te kojoj knjizi pripada</p>
    <p class="tutklasamini"> Bilješka se sprema žutom ikonom sa oznakom kvačice</p>
    <p class="tutklasamini"> Kako bi ažurirali prikaz bilješki pritisnemo ikonu u gornjem desnom kutu</p>
    <div class="row conclass2">
      <div class="col-md-4 col-8">
      <img src="tut3.png" class="tutimage img-fluid ">
      </div>
      <div class="col-md-4 col-8">
      <img src="tut4.png" class="tutimage2 img-fluid ">
      </div>
    </div>
  </div>
</div>

<div class="p-2" style="left:0;bottom:0;width:100%;background-color:#404040">
  <p style="color:white;font-size:16px;margin-left:3%">Kontaktirajte Nas:</p>
  <p style="color:white;font-size:12px;margin-left:3%">Ulica 123</p>
  <p style="color:white;font-size:12px;margin-left:3%">Netko@email.hr</p>
  <p style="color:white;font-size:12px;margin-left:3%">+385 98 111 1111</p>
</div>
</body>

<!-- carouselStyle1 custom klasa napravljen za carousel kako bi samo na malim uredajima (mobitelu) bio max-width 100%-->
<!-- donwloadClass custom klasa za prebacivanje flex directiona na malim ekranima u column-->
 <!-- update: klase premijestene iz <style> u zaseban fike -->

<style>

.navbar-light {
    background-color: #FFEBAA !important;
}

</style>
</html>